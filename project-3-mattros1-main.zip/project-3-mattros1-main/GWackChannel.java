public class GWackChannel{

    //TODO
}

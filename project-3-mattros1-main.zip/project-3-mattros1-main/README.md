# Project 3 : GWack Slack Simulator

## Help Received

Please document any help you received in completing this lab. Note that the what you submit should be your own work. Refer to the syllabus for more details. 

[ANSWER HERE]

## Describe the OOP design of your GWack Slack Simulator

Please provide a short description of your programming progress

[ANSWER HERE]

## What additional features did you attempt and how can we test them

[ANSWER HERE]



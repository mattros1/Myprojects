# OOP Design Document

[Update the path below so your UML diagram appears in the rendered markdown, once you do, remove this text!]

![](/path/to/UML.ong)

## Overview

[provide a general overview of your OOP design. Once you do, remove this text!]


[For each of the classes in your OOP design, including ones provided
for you, offer a brief description of their functionality and how they
interact. Be sure to highlight good OOP like encapsulation,
inheritance, and polymorphism. Once you do, remove this text! Also be
sure the headers below match the class names, and not Class 1 and
Class 2 and etc.]

## Class 1

## Class 2

## etc.

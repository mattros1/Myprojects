# Project 2


## Help Received

Please document any help you received in completing this lab. Note that the what you submit should be your own work. Refer to the syllabus for more details. 

[ANSWER HERE]

## Describe your work


## Part 1: UML Diagram

Note that you must do two tasks here:

1. Add to your repo a document `UML.png` that is a image of your UML diagram
2. Update the document `OOP-design.md` that describes your OOP design, referencing your document.
3. You will receive feedback on your design in a github issue

For your final submission, please update `UML.png` with the final UML diagram and `OOP-design.md` with your final description. Below describe the major changes you made.

[ANSWER HERE]

## Part 2: Implementation

What level simulation did you achieve

Level : [4] <-- choose one!

If you completed Level 4, describe the additional creature you added to the simulation.

[ANSWER HERE]
I created a phoenix creature that flies at 4 spaces per round. It can eat any other creature and cannto be killed by any other creature. It dies by starvation after 50 rounds and transforms into an egg which is a different creature class that does not move. The egg sits still for 100 rounds before hatching into another phoenix. The phoenix has a reduced range for targeting (10) as it is flying high up in the air. The amount of phoenixz added at the beggining will not change besides the egg process. The number of phoenixs should be put in args[3]. To do this i had to push the other args values back. I hope thats ok. I personally like using 2 phoenix so I ran my code with java Simulator 8 2 0 2 1000 42 | java -jar Plotter.jar 15 --DEBUG

